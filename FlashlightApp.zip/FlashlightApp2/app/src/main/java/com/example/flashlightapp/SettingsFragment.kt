package com.example.flashlightapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.RatingBar.OnRatingBarChangeListener
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.example.firstproject.R
import com.example.firstproject.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment(), View.OnClickListener {
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvShareApp.setOnClickListener(this)
        binding.tvRateUs.setOnClickListener(this)
        binding.tvFeedback.setOnClickListener(this)
        binding.tvCheckForUpdates.setOnClickListener(this)
        binding.tvPrivacyPolicy.setOnClickListener(this)
        binding.tvTermOfUse.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tvShareApp -> {
                onShareAppClick()
            }

            R.id.tvRateUs -> {
                onRateUsClick()
            }

            R.id.tvFeedback -> {
                onFeedbackClick()
            }

            R.id.tvCheckForUpdates -> {
                onCheckForUpdatesClick()
            }

            R.id.tvPrivacyPolicy -> {
                onPrivacyPolicyClick()
            }

            R.id.tvTermOfUse -> {
                onTermOfUseClick()
            }
        }
    }

    private fun onShareAppClick() {
        val shareText = "Check out this awesome app! [Insert app link here]"
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
        }
        startActivity(Intent.createChooser(shareIntent, "Share via"))
    }

    private fun onRateUsClick() {
            showCustomAlertDialog()
    }

    private fun onFeedbackClick() {
        val feedbackIntent = Intent(requireContext(), FeedbackActivity::class.java)
        startActivity(feedbackIntent)
    }

    private fun onCheckForUpdatesClick() {
    }

    private fun onPrivacyPolicyClick() {
        val privacyPolicyUrl = "https://policies.google.com/privacy?hl=en-US"
        val privacyIntent = Intent(Intent.ACTION_VIEW, Uri.parse(privacyPolicyUrl))
        startActivity(privacyIntent)
    }

    private fun onTermOfUseClick() {
        val privacyPolicyUrl = "https://policies.google.com/terms?hl=en"
        val privacyIntent = Intent(Intent.ACTION_VIEW, Uri.parse(privacyPolicyUrl))
        startActivity(privacyIntent)
    }

    private fun showCustomAlertDialog() {
        val inflater = LayoutInflater.from(requireActivity())
        val view = inflater.inflate(R.layout.custom_alert_layout, null)
        val closeButton: ImageButton = view.findViewById(R.id.closeButton)
        val image: ImageView = view.findViewById(R.id.dialogImage)
        val likeTextView: TextView = view.findViewById(R.id.dialogText)
        val helpTextView: TextView = view.findViewById(R.id.dialogSubText)
        val ratingBar: RatingBar = view.findViewById(R.id.ratingBar)
        val feedbackButton: Button = view.findViewById(R.id.btnFeedback)

        ratingBar.onRatingBarChangeListener =
            OnRatingBarChangeListener { ratingBar, rating, fromUser ->
                val rating = ratingBar.rating
                if (rating <= 3) {
                    feedbackButton.setText("Feedback")
                }else{
                    feedbackButton.setText("Rate Us")
                }
            }

        val builder = AlertDialog.Builder(requireActivity(), R.style.CustomAlertDialog)
            .setView(view)
            .setCancelable(true)

        val dialog = builder.create()
        dialog.window?.setBackgroundDrawableResource(R.drawable.dialog_background)



        closeButton.setOnClickListener {
            SettingsFragment()
            dialog.dismiss()
        }


        feedbackButton.setOnClickListener {
            val rating = ratingBar.rating
            if (rating <= 3) {
                val packageName = "com.example.flashlightapp"
                val playStoreUrl = "https://play.google.com/store/apps/details?id=$packageName"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(playStoreUrl))
                startActivity(intent)
            } else {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:")
                    putExtra(Intent.EXTRA_EMAIL, arrayOf("support@example.com"))
                    putExtra(Intent.EXTRA_SUBJECT, "Feedback on Flashlight App")
                    putExtra(Intent.EXTRA_TEXT, "Please share your feedback here...")
                }
                if (intent.resolveActivity(requireActivity().packageManager) != null) {
                    startActivity(intent)
                } else {
                    Toast.makeText(requireActivity(), "No email client found", Toast.LENGTH_SHORT).show()
                }
            }
            dialog.dismiss()
        }

        dialog.show()
    }

}


