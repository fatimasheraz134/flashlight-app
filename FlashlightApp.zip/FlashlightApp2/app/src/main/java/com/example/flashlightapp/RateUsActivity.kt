package com.example.flashlightapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.firstproject.R

class RateUsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rate_us)

        showCustomAlertDialog()
    }

    private fun showCustomAlertDialog() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.custom_alert_layout, null)
        val closeButton: ImageButton = view.findViewById(R.id.closeButton)
        val image: ImageView = view.findViewById(R.id.dialogImage)
        val likeTextView: TextView = view.findViewById(R.id.dialogText)
        val helpTextView: TextView = view.findViewById(R.id.dialogSubText)
        val ratingBar: RatingBar = view.findViewById(R.id.ratingBar)
        val feedbackButton: Button = view.findViewById(R.id.btnFeedback)

        val builder = AlertDialog.Builder(this, R.style.CustomAlertDialog)
            .setView(view)
            .setCancelable(true)

        val dialog = builder.create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        closeButton.setOnClickListener {
            navigateToSettingsFragment()
            dialog.dismiss()
        }

        feedbackButton.setOnClickListener {
            val rating = ratingBar.rating
            if (rating <= 3) {
                val packageName = "com.example.flashlightapp"
                val playStoreUrl = "https://play.google.com/store/apps/details?id=$packageName"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(playStoreUrl))
                startActivity(intent)
            } else {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:")
                    putExtra(Intent.EXTRA_EMAIL, arrayOf("support@example.com"))
                    putExtra(Intent.EXTRA_SUBJECT, "Feedback on Flashlight App")
                    putExtra(Intent.EXTRA_TEXT, "Please share your feedback here...")
                }
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "No email client found", Toast.LENGTH_SHORT).show()
                }
            }
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun navigateToSettingsFragment() {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("showSettingsFragment", true)
        startActivity(intent)
        finish()
    }
}