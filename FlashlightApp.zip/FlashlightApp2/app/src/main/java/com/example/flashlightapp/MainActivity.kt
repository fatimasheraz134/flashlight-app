package com.example.flashlightapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.example.firstproject.R
import com.example.firstproject.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

       val bottomNav: BottomNavigationView = binding.bottomNavigation
       bottomNav.setOnNavigationItemSelectedListener(navListener)
       if (savedInstanceState == null) {
           supportFragmentManager.beginTransaction().replace(R.id.fragment_container,
                FlashlightFragment()).commit()
       }
    }

    private val navListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        var selectedFragment: Fragment? = null

        when (item.itemId) {
            R.id.nav_flashlight -> selectedFragment = FlashlightFragment()
            R.id.nav_settings -> selectedFragment = SettingsFragment()
       }

        if (selectedFragment != null) {
          supportFragmentManager.beginTransaction().replace(R.id.fragment_container,
            selectedFragment).commit()
     }
        true
   }
}