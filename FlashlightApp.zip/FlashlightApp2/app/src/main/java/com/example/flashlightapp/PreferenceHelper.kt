package com.example.flashlightapp

import android.content.Context
import android.content.SharedPreferences

class PreferenceHelper(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("flashlight_preferences", Context.MODE_PRIVATE)

    fun saveToggleState(isChecked: Boolean) {
        sharedPreferences.edit().putBoolean("toggle_state", isChecked).apply()
    }

    fun getToggleState(): Boolean {
        return sharedPreferences.getBoolean("toggle_state", false)
    }

    fun saveSeekBarProgress(seekBarKey: String, progress: Int) {
        sharedPreferences.edit().putInt(seekBarKey, progress).apply()
    }

    fun getSeekBarProgress(seekBarKey: String): Int {
        return sharedPreferences.getInt(seekBarKey, 0)
    }
}
