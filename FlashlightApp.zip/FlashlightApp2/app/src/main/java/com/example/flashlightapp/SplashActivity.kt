package com.example.flashlightapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import com.example.firstproject.R

class SplashActivity : AppCompatActivity() {

    private lateinit var progressBar: ProgressBar
    private val splashScreenDuration: Long = 3000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        progressBar = findViewById(R.id.progressBar)
        progressBar.max = 100
        animateProgressBar()
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this@SplashActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, splashScreenDuration)
    }

    private fun animateProgressBar() {
        Thread {
            var progress = 0
            while (progress <= 100) {
                Thread.sleep(splashScreenDuration / 100)
                progressBar.progress = progress
                progress++
            }
        }.start()
    }
}
