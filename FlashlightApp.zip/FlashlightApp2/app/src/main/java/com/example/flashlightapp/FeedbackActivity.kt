package com.example.flashlightapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.firstproject.R

class FeedbackActivity : AppCompatActivity() {
    private lateinit var btnBack: ImageButton
    private lateinit var tvProblemsEncountered: TextView
    private lateinit var tvGiveFeedback: TextView
    private lateinit var etDescribeProblem: EditText
    private lateinit var btnSubmit: Button
    private lateinit var tvCharacterCount: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feedback)
        btnBack = findViewById(R.id.btnBack)
        tvProblemsEncountered = findViewById(R.id.tvProblemsEncountered)
        tvGiveFeedback = findViewById(R.id.tvGiveFeedback)
        etDescribeProblem = findViewById(R.id.etDescribeProblem)
        btnSubmit = findViewById(R.id.btnSubmit)
        tvCharacterCount = findViewById(R.id.tvCharCount)
        btnBack.setOnClickListener {
            finish()
        }
        etDescribeProblem.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val textLength = s?.length ?: 0
                tvCharacterCount.text = "$textLength/50"
                if (textLength > 50) {
                    etDescribeProblem.setText(s?.substring(0, 50))
                    etDescribeProblem.setSelection(etDescribeProblem.text.length)
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })
        btnSubmit.setOnClickListener {
            val feedbackText = etDescribeProblem.text.toString()
            if (feedbackText.isNotEmpty()) {
                val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:")
                    putExtra(Intent.EXTRA_EMAIL, arrayOf("your_email@example.com"))
                    putExtra(Intent.EXTRA_SUBJECT, "Feedback for Your App")
                    putExtra(Intent.EXTRA_TEXT, feedbackText)
                }
                startActivity(emailIntent)
//                if (emailIntent.resolveActivity(packageManager) != null) {
//                    startActivity(emailIntent)
//                } else {
//                    Toast.makeText(this, "No email app found", Toast.LENGTH_SHORT).show()
//                }
            } else {
                Toast.makeText(this, "Please enter your feedback", Toast.LENGTH_SHORT).show()
            }
        }
    }
}