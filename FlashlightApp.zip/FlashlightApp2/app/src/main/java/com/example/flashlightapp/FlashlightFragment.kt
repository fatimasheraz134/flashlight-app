package com.example.flashlightapp

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.firstproject.R
import com.example.firstproject.databinding.FragmentFlashlightBinding
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import com.google.android.material.snackbar.Snackbar
import java.util.Timer
import java.util.TimerTask

class FlashlightFragment : Fragment() {
    private lateinit var binding: FragmentFlashlightBinding
    private lateinit var cameraManager: CameraManager
    private lateinit var cameraId: String
    private var isFlashlightOn: Boolean = false

    private lateinit var requestPermissionLauncher: ActivityResultLauncher<String>
    private lateinit var resultLauncher: ActivityResultLauncher<Intent>

    private val flickerHandler: Handler = Handler(Looper.getMainLooper())
    private var flickerRunnable: Runnable? = null
    private var onDuration: Long = 0L
    private var offDuration: Long = 0L
    private var isFlickering: Boolean = false

    private lateinit var preferenceHelper: PreferenceHelper

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFlashlightBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        preferenceHelper = PreferenceHelper(requireContext())
        cameraManager = requireContext().getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            cameraId = cameraManager.cameraIdList[0]
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
        requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                handleFlashlightState()
            } else {
                Toast.makeText(requireContext(), "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }

        resultLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (ContextCompat.checkSelfPermission(
                        requireContext(),
                        Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    handleFlashlightState()
                }
            }
        binding.flashingSwitch.isChecked = preferenceHelper.getToggleState()
        binding.seekbarFlashDuration.progress = preferenceHelper.getSeekBarProgress("flash_duration")
        binding.seekbarAdditional.progress = preferenceHelper.getSeekBarProgress("additional_duration")
        binding.btnFlashlightToggle.setOnClickListener {
            handlePermission()
        }
        setupSeekBarListeners()
        binding.flashingSwitch.setOnCheckedChangeListener { _, isChecked ->
            preferenceHelper.saveToggleState(isChecked)
        }
    }

    private fun handlePermission() {
        when {
            ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED -> {
                handleFlashlightState()
            }

            shouldShowRequestPermissionRationale(Manifest.permission.CAMERA) -> {
                Snackbar.make(
                    binding.root,
                    "Camera permission is needed to turn on the flashlight",
                    Snackbar.LENGTH_INDEFINITE
                )
                    .setAction("Settings") {
                        goToPermissionSetting()
                    }.show()
            }

            else -> {
                requestPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun handleFlashlightState() {
        if (binding.flashingSwitch.isChecked) {
            if (isFlickering) {
                binding.layoutLock.visibility = View.GONE
                stopFlickering()
            } else {
                binding.layoutLock.visibility = View.VISIBLE
                startFlickering()
            }
        } else {
            if (isFlashlightOn) {
                binding.layoutLock.visibility = View.GONE
                turnFlashlightOff()
            } else {
                binding.layoutLock.visibility = View.VISIBLE
                turnFlashlightOn()
            }
        }
    }

    private fun goToPermissionSetting() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        val uri = Uri.fromParts("package", requireActivity().packageName, null)
        intent.data = uri
        resultLauncher.launch(intent)
    }

    private fun turnFlashlightOn() {
        try {
            cameraManager.setTorchMode(cameraId, true)
            isFlashlightOn = true
            if (!isFlickering){
                binding.btnFlashlightToggle.setColorFilter(
                    ContextCompat.getColor(requireContext(), R.color.flashlight_on)
                )
                binding.tvTurnFlashOn.text = "Turn Flash Off"
            }
        } catch (e: CameraAccessException) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Failed to turn on flashlight", Toast.LENGTH_SHORT).show()
        }
    }

    private fun turnFlashlightOff() {
        try {
            cameraManager.setTorchMode(cameraId, false)
            isFlashlightOn = false
            binding.btnFlashlightToggle.clearColorFilter()
            binding.tvTurnFlashOn.text = "Turn Flash On"
        } catch (e: CameraAccessException) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Failed to turn off flashlight", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startFlickering() {
        if (isFlickering) return

        onDuration = binding.seekbarFlashDuration.progress.toLong() * 10L
        offDuration = binding.seekbarAdditional.progress.toLong() * 10L

        flickerRunnable = object : Runnable {
            override fun run() {
                if (isFlashlightOn) {
                    turnFlashlightOff()
                    flickerHandler.postDelayed(this, offDuration)
                } else {
                    turnFlashlightOn()
                    flickerHandler.postDelayed(this, onDuration)
                }
            }
        }
        flickerHandler.post(flickerRunnable!!)
        isFlickering = true
    }

    private fun stopFlickering() {
        flickerRunnable?.let { flickerHandler.removeCallbacks(it) }
        flickerRunnable = null
        turnFlashlightOff()
        isFlickering = false
    }

    private fun setupSeekBarListeners() {
        binding.seekbarFlashDuration.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val timeInSeconds = (progress * 1.50 / seekBar?.max!!)
                binding.tvFlashDuration.text = String.format("%.2fs", timeInSeconds)
                preferenceHelper.saveSeekBarProgress("flash_duration", progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekbarAdditional.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val timeInSeconds = (progress * 1.50 / seekBar?.max!!)
                binding.tvDuration.text = String.format("%.2fs", timeInSeconds)
                preferenceHelper.saveSeekBarProgress("additional_duration", progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }
}
